import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

class WordDictionary extends Dictionary<String,List<String>>{

	private HashMap<String,List<String>> dictionary ;
	
	@Override
	public int size() {
		return dictionary.size();
	}

	@Override
	public boolean isEmpty() {
		if(dictionary.size() == 0)
			return true;
		else
		return false;
	}

	@Override
	public Enumeration keys() {
		
		Set<String> keys= dictionary.keySet();
		Enumeration keysEnumeration = Collections.enumeration(keys);
		return keysEnumeration; 
		
	}

	@Override
	public Enumeration elements() {
		Collection<List<String>> values= dictionary.values();
		Enumeration valuesEnumeration = Collections.enumeration(values);
		return valuesEnumeration; 
	}

	@Override
	public List<String> get(Object key) {
		return dictionary.get(key);
	}

	@Override
	public List<String> put(String key, List<String> value) {
		return  dictionary.put(key,value); 
	}
	
	@Override
	public List<String> remove(Object key) {
		return dictionary.remove(key);
	}

	public Boolean search(String key) {
		if(dictionary.containsKey(key)) {
			return Boolean.TRUE;
		}
		else 
			return Boolean.FALSE;
	}
	
	WordDictionary(){
		dictionary = new HashMap<String,List<String>>();		
	}

	
}

public class DictionaryUtility{
	
	WordDictionary  dictionary = new WordDictionary();
	URL url = getClass().getResource("dict");
    String path =url.getPath();
	
	public WordDictionary fillDictonary() {
			//read file into stream, try-with-resources
		
			try (Stream<String> stream = Files.lines(Paths.get(path))) {

				stream.forEach(line->{ 
				String set[] = line.split(":");
				
				for(String words:set) {
					 List<String> valuesList = new ArrayList<String>();
					 String[] values = set[1].split("\\d.");
					 for(String value : values)
					 {
						 valuesList.add(value);
					 }
					 set[0] = set[0].replaceAll("\"", "").trim();
					 //System.out.println(set[0]);
						 dictionary.put(set[0],valuesList);
				}
				
				});			
						
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			
			return dictionary;
	}
	public static void main(String[] args) {
	
		DictionaryUtility du = new DictionaryUtility();
		du.fillDictonary();
	}
}